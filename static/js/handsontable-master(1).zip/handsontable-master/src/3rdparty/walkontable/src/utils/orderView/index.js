import OrderView from './view';
import SharedOrderView from './sharedView';

export {
  OrderView,
  SharedOrderView,
};
