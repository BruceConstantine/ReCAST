from django.apps import AppConfig


class RecastConfig(AppConfig):
    name = 'ReCAST'
